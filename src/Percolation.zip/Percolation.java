import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

	private final boolean[][] grids;
	private final int gridSz;
	private final WeightedQuickUnionUF uf;
	private int openSites;
	private final int topVirtualIndex;
	private final int bottomVirtualIndex;

	// creates n-by-n grid, with all sites initially blocked
	public Percolation(int n) {
		gridSz = n;
		int totalSites = n * n;
		topVirtualIndex = totalSites + 1;
		bottomVirtualIndex = totalSites + 2;
		grids = new boolean[n][n];
		uf = new WeightedQuickUnionUF(totalSites + 2); // 2 is for 2 virtual sites for top row and bottom row
														// respectively
		// connect all top to topVirtualIndex
		for (int i = 0; i < gridSz; i++) {
			uf.union(i, topVirtualIndex - 1);
		}

		// connect all bottom to bottomVirtualIndex
		for (int i = totalSites - n; i < totalSites; i++) {
			uf.union(i, bottomVirtualIndex - 1);
		}

	}

	// opens the site (row, col) if it is not open already
	public void open(int row, int col) {
		validate(row);
		validate(col);
		if (!grids[row - 1][col - 1]) {
			grids[row - 1][col - 1] = true;
			openSites++;
			int ufIndex = siteIndex(row, col);
			// top row
			int topRow = row - 1;
			if (validateIndex(topRow) && grids[topRow - 1][col - 1]) {
				int topRowIndex = siteIndex(topRow, col);
				uf.union(ufIndex, topRowIndex);
			}
			// bottom row
			int bottomRow = row + 1;
			if (validateIndex(bottomRow) && grids[bottomRow - 1][col - 1]) {
				int bottomRowIndex = siteIndex(bottomRow, col);
				uf.union(ufIndex, bottomRowIndex);
			}

			// right column
			int rightColumnRow = col + 1;
			if (validateIndex(rightColumnRow) && grids[row - 1][rightColumnRow - 1]) {
				int rightColumnIndex = siteIndex(row, rightColumnRow);
				uf.union(ufIndex, rightColumnIndex);
			}
			// left column
			int leftColumnRow = col - 1;
			if (validateIndex(leftColumnRow) && grids[row - 1][leftColumnRow - 1]) {
				int leftColumnIndex = siteIndex(row, leftColumnRow);
				uf.union(ufIndex, leftColumnIndex);
			}

		}

	}

	// is the site (row, col) open?
	public boolean isOpen(int row, int col) {
		validate(row);
		validate(col);
		return grids[row - 1][col - 1];
	}

	// is the site (row, col) full?
	public boolean isFull(int row, int col) {
		validate(row);
		validate(col);
		if (row == 1)
			return isOpen(row, col);
		else if (isOpen(row, col)) {
			int root1 = uf.find(siteIndex(row, col));
			int root2 = uf.find(topVirtualIndex - 1);
			return root1 == root2;
		} else
			return false;
	}

	// returns the number of open sites
	public int numberOfOpenSites() {
		return openSites;
	}

	// does the system percolate?
	public boolean percolates() {
		return uf.find(topVirtualIndex - 1) == uf.find(bottomVirtualIndex - 1);
	}

	private boolean validateIndex(int index) {
		return index <= gridSz && index > 0;
	}

	private void validate(int index) {
		if (!validateIndex(index))
			throw new IllegalArgumentException("Invalidate index " + index + " has to be between 1 and " + gridSz);
	}

	private int siteIndex(int row, int col) {
		return (row - 1) * gridSz + col - 1;
	}

	private void show() {
		for (int i = 0; i < gridSz; i++) {
			for (int j = 0; j < gridSz; j++) {
				if (grids[i][j])
					System.out.print("O");
				else
					System.out.print("X");
			}
			System.out.println("");
		}
	}

	// test client (optional)
	public static void main(String[] args) {
		Percolation t = new Percolation(5);
		t.show();
		System.out.println("isPercolates: " + t.percolates());
		t.open(1, 2);
		t.open(1, 3);
		t.open(3, 2);
		t.open(3, 3);
		t.open(4, 3);
		t.open(5, 3);
		t.open(2, 2);
		t.show();
		System.out.println("isPercolates: " + t.percolates());
	}
}